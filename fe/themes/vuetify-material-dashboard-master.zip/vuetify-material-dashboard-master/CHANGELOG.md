# Change Log

## [2.0.0] 2019-08-23
### Updated Dependencies
- all dependencies updated

## [1.0.0] 2018-10-16
### Initial Release
