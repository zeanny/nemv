<script>
  import { VCard } from 'vuetify/lib'

  export default {
    name: 'BaseCard',

    extends: VCard
  }
</script>
