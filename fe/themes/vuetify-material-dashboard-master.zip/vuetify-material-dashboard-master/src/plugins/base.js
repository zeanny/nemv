import Vue from 'vue'
import BaseCard from '@/components/base/Card'

Vue.components(BaseCard.name, BaseCard)
